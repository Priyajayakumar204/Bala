package com.capgemini.qrf.entry;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JTextArea;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import com.capgemini.qrf.models.QueryReviewForm;
import com.capgemini.qrf.services.QueryConvertor;
import com.capgemini.qrf.services.WordInterface;

public class AppLoader {
	
	public static XWPFDocument docx = null;
	public static XWPFTable table  = null;
	
	public static String  start(QueryReviewForm data,String filePath) {
		String message = null;
		try {
			if(filePath == null || filePath.trim().equals(""))
				return "Please select valid log file.";
			
			File file = new File(filePath);
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
			String dateAsString = simpleDateFormat.format(new Date());
			String userDir = System.getProperty("user.home");
			File output = new File(userDir+"\\Desktop\\QueryReviewForm_"+dateAsString+".docx");
		
			docx = new XWPFDocument(AppLoader.class.getResourceAsStream("/docs/QueryReviewFormTemplate.docx"));

			table = WordInterface.getTemplateTable(docx);
			
			WordInterface.populateFormData(docx, table, data);
			
			QueryConvertor.readAllQueries(file, docx, table, data);
			
			docx.removeBodyElement(docx.getPosOfTable(table));
			
			FileOutputStream out = new FileOutputStream(output);
			docx.write(out);
            out.close();
          
            //SQL Document fetch starts
            String queryStringData=data.getSql();
        	File sqlFile = new File(userDir+"\\Desktop\\SQLQuery_"+dateAsString+".sql");     	  
            FileOutputStream fos =null;   
            
    		try {

    			fos = new FileOutputStream(sqlFile);
    			if (!sqlFile.exists()) {
    				sqlFile.createNewFile();
    			}
    			// get the content in bytes
    			byte[] 	contentInBytes = queryStringData.getBytes();
    			fos.write(contentInBytes);
	    		fos.flush();
	    		fos.close();
    			
    		} catch (IOException e) {
    			e.printStackTrace();
    		}

    		finally {
    			try {
    				if (fos != null) {
    					fos.close();
    				}
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}

            
            if (Desktop.isDesktopSupported()) 
            	Desktop.getDesktop().open(output);
            
            
            if (Desktop.isDesktopSupported()) 
            	Desktop.getDesktop().open(sqlFile);
            
            message =  "";
            
		} catch (FileNotFoundException e) {
			message = e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			message = e.getMessage();
			e.printStackTrace();
		} catch (NullPointerException e) {
		message = "Please select valid log file.";
		e.printStackTrace();
		}catch (Exception e) {
			message = e.getMessage();
			e.printStackTrace();
		}
		return message;
		
	}

}