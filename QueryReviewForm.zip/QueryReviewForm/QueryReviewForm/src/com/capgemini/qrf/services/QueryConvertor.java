package com.capgemini.qrf.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JTextArea;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import com.capgemini.qrf.models.QueryReviewForm;

public class QueryConvertor {
	
	
	
	public static List<String> readAllQueries(File file,XWPFDocument document,XWPFTable table,QueryReviewForm data) throws Exception {
		
		BufferedReader br = null;
		 List<String> queryList=null;
		try {
			FileInputStream fstream = new FileInputStream(file);
			br = new BufferedReader(new InputStreamReader(fstream));
			String strLine;
			
			String query = null;
			Set<String> queries = new HashSet<String>();
			queryList=new ArrayList<String>();
				String queryStringData="";
				//
			while ((strLine = br.readLine()) != null) {
				try {
						String parameters = null;
						if (strLine.contains("Preparing:")) {
							query = strLine.substring(strLine.indexOf("Preparing:") + 10);
						}
						if (strLine.contains("Parameters:")) {
							parameters = strLine.substring(strLine.indexOf("Parameters:") + 11);
						}
						if (parameters != null && !"".equals(parameters.trim()) && queries.add(query)) {
							String[] arrParameters = parameters.split(",");
							for (int i = 0; i < arrParameters.length; i++) {
								if (arrParameters[i].substring(arrParameters[i].indexOf("(")).contains("String")) {
									query = query.replaceFirst("\\?",
											"'" + arrParameters[i].substring(0, arrParameters[i].indexOf("(")).trim() + "'");
								} else {
									query = query.replaceFirst("\\?",
											arrParameters[i].substring(0, arrParameters[i].indexOf("(")).trim());
								}
							}
							
							data.setSql(query);
							//textArea.getDocument();
							WordInterface.writeQueryInfo(document, table,data);
						
					     	   queryList.add(query);
					     	   
					 			for(String qData : queryList)
					 			{
					 				queryStringData +=  qData +";"+ "\n" + "\n"+"\n" + "\n";
					 	
					 				} 
						}
				}
				catch (Exception e) {
					//Empty Catch Block
				}
			}
			
			//Data set for Sql File 
			data.setSql(queryStringData);
			
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new Exception(e);
			}
		}
		return queryList;
	
 	   
    }
}