
package com.capgemini.qrf.services;

import java.io.File;
import java.io.FileOutputStream; 
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.xmlbeans.XmlCursor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRow;
  

import com.capgemini.qrf.models.QueryReviewForm;
 
 
public class WordInterface {
      
       public static XWPFTable getTemplateTable(XWPFDocument document) {
    	   for (XWPFTable table : document.getTables()) {
    		  //document.removeBodyElement(document.getPosOfTable(table));
    		  return table;
    	   }
		return null;
       }
       
       public static QueryReviewForm writeQueryInfo(XWPFDocument document,XWPFTable table,QueryReviewForm data) {
    	   XWPFParagraph paragraph = document.createParagraph();
    	   XWPFRun run = paragraph.createRun();
    	   run.addBreak(); 
    	   XmlCursor cursor = paragraph.getCTP().newCursor();
    	   XWPFTable table2 =  document.insertNewTbl(cursor);
           table2.removeRow(0);
           List<XWPFTableRow> rows = table.getRows();
           for (int i = 0; i < rows.size(); i++) {
        	   CTRow ctRow = CTRow.Factory.newInstance();
        	   ctRow.set(rows.get(i).getCtRow());
        	   XWPFTableRow row2 = new XWPFTableRow(ctRow, table);
      		 	if(i == 6) row2.getCell(1).setText(data.getSql());
                table2.addRow(row2);
           }
         
           
           data.setTable(table2);
           data.setDocument(document); 
           
           return data;
           
		
       }
       
      
     /* public void writeOnlyQuery(XWPFDocument document,XWPFTable table,QueryReviewForm data)   
    	      {   
    	        
    	       XWPFParagraph QueryParagraph = document.createParagraph();   
    	       XWPFRun tmpRun = QueryParagraph.createRun();   
    	       tmpRun.setText(data.getSql());    
    	          	    }   
       
       */
       
       
       
       public static void populateFormData(XWPFDocument document,XWPFTable table,QueryReviewForm data) {
           List<XWPFTableRow> rows = table.getRows();
           for (int i = 0; i < rows.size(); i++) {
        	   switch (i) {
					case 0:
						rows.get(i).getCell(1).setText(data.getAppName());
						rows.get(i).getCell(3).setText(data.getEnteredBy());
						break;
					case 1:
						rows.get(i).getCell(1).setText(data.getDueDate());
						rows.get(i).getCell(3).setText(data.getEnteredDate());				
						break;
					case 2:
						rows.get(i).getCell(1).setText(data.getItgNo());
						rows.get(i).getCell(3).setText(data.getUserProfile());
						break;
					case 3:
						rows.get(i).getCell(1).setText(data.getProdSys());
						rows.get(i).getCell(3).setText(data.getDbType());
						break;
					case 5:
						rows.get(i).getCell(1).setText(data.getSchema());
						rows.get(i).getCell(3).setText(data.getQaSys());
						break;
					case 7:
						rows.get(i).getCell(1).setText(data.getPriority());
						rows.get(i).getCell(3).setText(data.getAppType());
						break;
					case 8:
						rows.get(i).getCell(1).setText(data.getRunTime());
						rows.get(i).getCell(3).setText(data.getIsNewOrModified());
						break;
					default:
						break;
				}
           }
       }
}
