package com.capgemini.qrf.models;

import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

public class QueryReviewForm {
	
	private String appName;
	private String enteredBy;
	private String dueDate;
	private String enteredDate;
	private String itgNo;
	private String userProfile;
	private String prodSys;
	private String dbType;
	private String comments;
	private String schema;
	private String qaSys;
	private String sql;
	private String priority;
	private String appType;
	private String environment;
	private String connectionDetails;
	private String runTime;
	private String isNewOrModified;
	private String prevSql;
	private XWPFTable table;
	private XWPFDocument document;
	
	
	public XWPFDocument getDocument() {
		return document;
	}
	public void setDocument(XWPFDocument document) {
		this.document = document;
	}
	public XWPFTable getTable() {
		return table;
	}
	public void setTable(XWPFTable table) {
		this.table = table;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getEnteredBy() {
		return enteredBy;
	}
	public void setEnteredBy(String enteredBy) {
		this.enteredBy = enteredBy;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getEnteredDate() {
		return enteredDate;
	}
	public void setEnteredDate(String enteredDate) {
		this.enteredDate = enteredDate;
	}
	public String getItgNo() {
		return itgNo;
	}
	public void setItgNo(String itgNo) {
		this.itgNo = itgNo;
	}
	public String getUserProfile() {
		return userProfile;
	}
	public void setUserProfile(String userProfile) {
		this.userProfile = userProfile;
	}
	public String getProdSys() {
		return prodSys;
	}
	public void setProdSys(String prodSys) {
		this.prodSys = prodSys;
	}
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getQaSys() {
		return qaSys;
	}
	public void setQaSys(String qaSys) {
		this.qaSys = qaSys;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getConnectionDetails() {
		return connectionDetails;
	}
	public void setConnectionDetails(String connectionDetails) {
		this.connectionDetails = connectionDetails;
	}
	public String getRunTime() {
		return runTime;
	}
	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}
	public String getIsNewOrModified() {
		return isNewOrModified;
	}
	public void setIsNewOrModified(String isNewOrModified) {
		this.isNewOrModified = isNewOrModified;
	}
	public String getPrevSql() {
		return prevSql;
	}
	public void setPrevSql(String prevSql) {
		this.prevSql = prevSql;
	}
}